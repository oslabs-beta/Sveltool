<script>
import PickerButton from "./PickerButton.svelte";
import ProfileButton from "./ProfileButton.svelte";
import VisibilityButton from "./VisibilityButton.svelte";
import Search from "./Search.svelte";
import Toolbar from "./Toolbar.svelte";
</script>


<Toolbar>
   <PickerButton/>
    <ProfileButton />
   <VisibilityButton />
    <Search />   
</Toolbar>
   

<style>

 
</style>
